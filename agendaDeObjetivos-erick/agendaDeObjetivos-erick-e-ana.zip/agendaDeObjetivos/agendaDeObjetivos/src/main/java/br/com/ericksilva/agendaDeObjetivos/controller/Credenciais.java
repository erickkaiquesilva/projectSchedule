package br.com.ericksilva.agendaDeObjetivos.controller;

public class Credenciais {

	public Credenciais(String string, String string2) {
		// TODO Auto-generated constructor stub
	}

}
