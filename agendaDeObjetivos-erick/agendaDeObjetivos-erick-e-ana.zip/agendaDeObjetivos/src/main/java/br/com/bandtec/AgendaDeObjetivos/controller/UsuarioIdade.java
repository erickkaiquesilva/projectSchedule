package br.com.bandtec.AgendaDeObjetivos.controller;

public class UsuarioIdade {

}
